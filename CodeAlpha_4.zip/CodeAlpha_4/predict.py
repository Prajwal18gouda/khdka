import pickle

# Path of the trained model
MODEL_PATH = "models/sentiment_model.pkl"


# Load the trained model
try:
    with open(MODEL_PATH, "rb") as file:
        model = pickle.load(file)

    print("Model loaded successfully!")

except FileNotFoundError:
    print("Error: Model file not found!")
    print("Please run train_model.py first.")
    exit()


def predict_sentiment(text):
    """
    Predict the sentiment of the given text.
    """

    # Predict sentiment
    prediction = model.predict([text])[0]

    # Get prediction probabilities
    probabilities = model.predict_proba([text])[0]

    # Get class names
    classes = model.classes_

    # Find highest probability
    confidence = max(probabilities) * 100

    return prediction, confidence


# Main program
if __name__ == "__main__":

    print("\n===================================")
    print("       SENTIMENT ANALYSIS")
    print("===================================")
    print("Type 'exit' to stop the program.")

    while True:

        text = input("\nEnter your text: ")

        # Exit condition
        if text.lower() == "exit":
            print("\nProgram ended.")
            break

        # Check empty input
        if not text.strip():
            print("Please enter some text.")
            continue

        # Predict
        sentiment, confidence = predict_sentiment(text)

        # Display result
        print("\n-----------------------------------")
        print("Text       :", text)
        print("Sentiment  :", sentiment.upper())
        print(f"Confidence : {confidence:.2f}%")
        print("-----------------------------------")