import os
import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# -----------------------------
# Paths
# -----------------------------
DATA_PATH = "dataset/reviews.csv"
MODEL_PATH = "models/sentiment_model.pkl"


# -----------------------------
# Create models folder
# -----------------------------
os.makedirs("models", exist_ok=True)


# -----------------------------
# Load dataset
# -----------------------------
print("Loading dataset...")

df = pd.read_csv(DATA_PATH)

print("\nDataset Preview:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nSentiment Distribution:")
print(df["sentiment"].value_counts())


# -----------------------------
# Remove missing values
# -----------------------------
df = df.dropna(subset=["text", "sentiment"])


# -----------------------------
# Features and target
# -----------------------------
X = df["text"]
y = df["sentiment"]


# -----------------------------
# Train-test split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# -----------------------------
# Create ML pipeline
# -----------------------------
model = Pipeline([
    (
        "tfidf",
        TfidfVectorizer(
            lowercase=True,
            stop_words="english",
            ngram_range=(1, 2)
        )
    ),
    (
        "classifier",
        LogisticRegression(
            max_iter=1000
        )
    )
])


# -----------------------------
# Train model
# -----------------------------
print("\nTraining model...")

model.fit(X_train, y_train)


# -----------------------------
# Predictions
# -----------------------------
y_pred = model.predict(X_test)


# -----------------------------
# Evaluation
# -----------------------------
accuracy = accuracy_score(y_test, y_pred)

print("\n==============================")
print("MODEL PERFORMANCE")
print("==============================")

print(f"Accuracy: {accuracy * 100:.2f}%")

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))


# -----------------------------
# Save model
# -----------------------------
with open(MODEL_PATH, "wb") as file:
    pickle.dump(model, file)


print("\nModel saved successfully!")
print(f"Location: {MODEL_PATH}")