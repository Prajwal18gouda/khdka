import streamlit as st
import pickle
import pandas as pd
import matplotlib.pyplot as plt


# -----------------------------
# Load model
# -----------------------------
MODEL_PATH = "models/sentiment_model.pkl"

with open(MODEL_PATH, "rb") as file:
    model = pickle.load(file)


# -----------------------------
# Page configuration
# -----------------------------
st.set_page_config(
    page_title="Sentiment Analysis",
    page_icon="💬",
    layout="centered"
)


# -----------------------------
# Title
# -----------------------------
st.title("💬 Sentiment Analysis")
st.write(
    "Analyze text and classify it as Positive, Negative, or Neutral."
)


# -----------------------------
# Text input
# -----------------------------
text = st.text_area(
    "Enter your text:",
    placeholder="Example: I really love this product!"
)


# -----------------------------
# Analyze button
# -----------------------------
if st.button("Analyze Sentiment"):

    if text.strip() == "":
        st.warning("Please enter some text.")

    else:

        # Prediction
        prediction = model.predict([text])[0]

        # Probability
        probabilities = model.predict_proba([text])[0]

        classes = model.classes_

        probability_data = pd.DataFrame({
            "Sentiment": classes,
            "Probability": probabilities
        })

        confidence = max(probabilities) * 100


        # -----------------------------
        # Display result
        # -----------------------------
        st.subheader("Result")

        if prediction == "positive":
            st.success("😊 Positive Sentiment")

        elif prediction == "negative":
            st.error("😞 Negative Sentiment")

        else:
            st.info("😐 Neutral Sentiment")


        st.write(f"**Confidence:** {confidence:.2f}%")


        # -----------------------------
        # Probability chart
        # -----------------------------
        st.subheader("Sentiment Probabilities")

        chart_data = probability_data.set_index("Sentiment")

        st.bar_chart(chart_data)


        # -----------------------------
        # Details
        # -----------------------------
        st.subheader("Analysis")

        st.write("**Input Text:**")
        st.write(text)

        st.write("**Predicted Sentiment:**")
        st.write(prediction.capitalize())